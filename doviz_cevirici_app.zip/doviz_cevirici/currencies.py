# coding:utf-8

currency_list = ["USD - Amerikan Doları", "EUR - Euro", "JPY - Japon Yeni", "GBP - İngiliz Sterlini",
                 "AUD - Avustralya Doları", "CAD - Kanada Doları", "CHF - İsviçre Frangı", "CNY - Çin Yuanı",
                 "SEK - İsveç Kronu", "NZD - Yeni Zelanda Doları", "MXN - Meksika Pesosu", "SGD - Singapur Doları",
                 "HKD - Hong Kong Doları", "NOK - Norveç Kronu", "KRW - Güney Kore Wonu", "TRY - Türk Lirası",
                 "INR - Hindistan Rupisi", "RUB - Rus Rublesi", "BRL - Brezilya Reali", "ZAR - Güney Afrika Randı",
                 "DKK - Danimarka Kronu", "PLN - Polonya Zlotisi", "TWD - Tayvan Doları", "THB - Tayland Bahtı",
                 "MYR - Malezya Ringgiti"]
